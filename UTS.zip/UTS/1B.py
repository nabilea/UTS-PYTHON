rate = 1.1

def hitung(x):
    return x * rate

