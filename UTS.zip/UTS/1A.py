# 1A.py
# Perintah dijalankan lewat terminal:
# python -m venv venv
# .\.venv\Scripts\Activate
# pip install "requests==2.*"
# python kasir.py
